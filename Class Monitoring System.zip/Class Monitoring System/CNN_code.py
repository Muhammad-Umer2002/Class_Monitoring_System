import tkinter as tk
from tkinter import ttk, filedialog
from PIL import Image, ImageTk
from keras.models import Sequential
from keras.layers import Convolution2D, MaxPooling2D, Flatten, Dense
from keras.preprocessing.image import ImageDataGenerator, img_to_array, load_img
import numpy as np
import os

# Class for the third window (Prediction Window)
class ThirdWindow:
    def __init__(self, root, class_label, classifier, back_callback):
        # Initialize the window
        self.root = root
        self.root.title("Prediction Window")
        self.root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")
        self.root.configure(bg='#1E90FF')

        # Load background image
        bg_image_path = "Background_window3_Pic.jpg"
        bg_image = ImageTk.PhotoImage(Image.open(bg_image_path).resize((root.winfo_screenwidth(), root.winfo_screenheight())))
        bg_label = ttk.Label(self.root, image=bg_image)
        bg_label.image = bg_image
        bg_label.place(relx=0.5, rely=0.5, anchor='center')

        # Create GUI elements (buttons, labels)
        self.select_image_button = ttk.Button(self.root, text="Select Image", command=self.load_image, style='TButton')
        self.select_image_button.pack(pady=10)

        self.image_label = ttk.Label(self.root, style='TImage.TLabel')
        self.image_label.pack(pady=10)

        self.predict_button = ttk.Button(self.root, text="Predict", command=self.predict_image, style='TButton')
        self.predict_button.pack(pady=10)

        self.exit_button = ttk.Button(self.root, text="Exit", command=self.on_exit_button_click, style='TButton')
        self.exit_button.pack(pady=10)

        self.back_button = ttk.Button(self.root, text="Back", command=back_callback, style='TButton')
        self.back_button.pack(pady=10)

        self.result_label = ttk.Label(self.root, text="", font=('Arial', 16), style='TLabel')
        self.result_label.pack(pady=10)

        self.class_label = class_label
        self.classifier = classifier

    def predict_image(self):
        # Predict the class of the selected image
        if hasattr(self, 'selected_image_path'):
            img = load_img(self.selected_image_path, target_size=(256, 256))
            img_array = img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array /= 255.0

            result = self.classifier.predict(img_array)
            prediction = result[0, 0]

            # Process the prediction based on the class label
            if self.class_label == "Cheating":
                self.process_cheating_detection(prediction)
            elif self.class_label == "Fighting":
                self.process_fighting_detection(prediction)
            else:
                self.result_label.config(text="Invalid class label", foreground="red")
        else:
            self.result_label.config(text="Please select an image first", foreground="red")

    def process_cheating_detection(self, prediction):
        # Process the cheating prediction result
        if prediction > 0.5:
            self.result_label.config(text="Cheating Detected", foreground="red")
        else:
            self.result_label.config(text="No Cheating Detected", foreground="green")

    def process_fighting_detection(self, prediction):
        # Process the fighting prediction result
        if prediction > 0.5:
            self.result_label.config(text="Fighting Detected", foreground="red")
        else:
            self.result_label.config(text="No Fighting Detected", foreground="green")

    def on_exit_button_click(self):
        # Close the window
        if self.root:
            self.root.destroy()

    def load_image(self):
        # Load an image for prediction
        self.result_label.config(text="")
        
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            self.image = Image.open(file_path)
            self.image.thumbnail((400, 400))
            self.tk_image = ImageTk.PhotoImage(self.image)
            self.image_label.config(image=self.tk_image)
            self.image_label.image = self.tk_image
            self.selected_image_path = file_path

        if hasattr(self, 'back_callback'):
            self.back_callback()

# Class for the second window (Choose Detection Type)
class SecondWindow:
    def __init__(self, root, cheating_classifier, fighting_classifier):
        # Initialize the window
        self.root = root
        self.root.title("Choose Detection Type")
        self.root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")
        self.root.configure(bg='#1E90FF')
        self.root.protocol("WM_DELETE_WINDOW", self.on_second_window_close)

        # Load background image
        bg_image_path = "Background_window2_Pic.jpg"
        bg_image = ImageTk.PhotoImage(Image.open(bg_image_path).resize((root.winfo_screenwidth(), root.winfo_screenheight())))
        bg_label = ttk.Label(self.root, image=bg_image)
        bg_label.image = bg_image
        bg_label.place(relx=0.5, rely=0.5, anchor='center')

        # Create GUI elements (buttons, labels)
        title_label = ttk.Label(self.root, text="Please Select Which Detection to Perform", font=('Arial', 18, 'bold', 'underline'), foreground='white', background='#1E90FF')
        title_label.pack(pady=10)

        self.selected_option = tk.StringVar()

        self.cheating_panel = ttk.Frame(self.root, style='TBox.TLabel')
        self.cheating_panel.pack(side=tk.LEFT, padx=10)
        self.cheating_box = ttk.Radiobutton(self.cheating_panel, text="Cheating Detection", variable=self.selected_option, value="Cheating", style='TRadiobutton')
        self.cheating_box.pack(pady=5)
        self.cheating_button = ttk.Button(self.cheating_panel, text="Detect", command=self.detect_activity, style='TButton')
        self.cheating_button.pack(pady=10)

        self.fighting_panel = ttk.Frame(self.root, style='TBox.TLabel')
        self.fighting_panel.pack(side=tk.RIGHT, padx=10)
        self.fighting_box = ttk.Radiobutton(self.fighting_panel, text="Fighting Detection", variable=self.selected_option, value="Fighting", style='TRadiobutton')
        self.fighting_box.pack(pady=5)
        self.fighting_button = ttk.Button(self.fighting_panel, text="Detect", command=self.detect_activity, style='TButton')
        self.fighting_button.pack(pady=10)

        self.clear_button = ttk.Button(self.root, text="Clear Selection", command=self.clear_selection, style='TButton')
        self.clear_button.pack(pady=10)

        self.preview_image_label = ttk.Label(self.root, style='TImage.TLabel')
        self.preview_image_label.pack(pady=10)

        self.exit_button = ttk.Button(self.root, text="Exit", command=self.on_exit_button_click, style='TButton')
        self.exit_button.pack(pady=10)

        self.cheating_classifier = cheating_classifier
        self.fighting_classifier = fighting_classifier

    def detect_activity(self):
        # Detect the selected activity type
        selected_option = self.selected_option.get()
        if selected_option:
            if selected_option == "Cheating":
                classifier = self.cheating_classifier
            elif selected_option == "Fighting":
                classifier = self.fighting_classifier

            if classifier:
                self.root.withdraw()
                third_window = tk.Toplevel(self.root)
                ThirdWindow(third_window, selected_option, classifier, self.back_to_second_window)

    def back_to_second_window(self):
        # Go back to the second window
        self.root.deiconify()

    def on_second_window_close(self):
        # Handle close event for the second window
        if self.root:
            self.root.destroy()

    def on_exit_button_click(self):
        # Handle exit button click event
        if self.root:
            self.root.destroy()

    def clear_selection(self):
        # Clear the selected option
        self.selected_option.set("")
        self.preview_image_label.config(image=None)

# Class for the main application
class StudentActivityRecognitionApp:
    def __init__(self, root):
        # Initialize the main application
        self.root = root
        self.root.title("Student Activity Recognition System")
        self.root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")
        self.root.configure(bg='black')

        # Load background image and logos
        bg_image_path = "Background_pic.jpg"
        bg_image = ImageTk.PhotoImage(Image.open(bg_image_path).resize((root.winfo_screenwidth(), root.winfo_screenheight())))
        bg_label = ttk.Label(self.root, image=bg_image)
        bg_label.image = bg_image
        bg_label.place(relx=0.5, rely=0.5, anchor='center')

        left_logo_path = "left_logo.png"
        left_logo = ImageTk.PhotoImage(Image.open(left_logo_path).resize((250, 220)))
        left_logo_label = ttk.Label(self.root, image=left_logo, background='black', text="SIR SYED UNIVERSITY OF ENGINEERING & TECHNOLOGY", font=('Arial', 18, 'bold', 'underline'), foreground='white')
        left_logo_label.image = left_logo
        left_logo_label.place(relx=0.1, rely=0.5, anchor='center')

        right_logo_path = "right_logo.png"
        right_logo = ImageTk.PhotoImage(Image.open(right_logo_path).resize((220, 220)))
        right_logo_label = ttk.Label(self.root, image=right_logo, background='black', text="SOFTWARE ENGINEERING DEPARTMENT\n               ARTIFICIAL INTELLIGENCE", font=('Arial', 14, 'bold'), foreground='white')
        right_logo_label.image = right_logo
        right_logo_label.place(relx=0.9, rely=0.5, anchor='center')

        university_label = ttk.Label(self.root, text="SIR SYED UNIVERSITY OF ENGINEERING & TECHNOLOGY", font=('Arial', 18, 'bold', 'underline'), foreground='white', background='black')
        university_label.place(relx=0.5, rely=0.1, anchor='center')

        software_label = ttk.Label(self.root, text="SOFTWARE ENGINEERING DEPARTMENT\n               ARTIFICIAL INTELLIGENCE", font=('Arial', 14, 'bold'), foreground='white', background='black')
        software_label.place(relx=0.5, rely=0.2, anchor='center')

        welcome_label = ttk.Label(self.root, text="WELCOME TO CLASS MONITORING SYSTEM", font=('Arial', 20, 'bold'), foreground='white', background='black')
        welcome_label.place(relx=0.5, rely=0.3, anchor='center')

        # Configure the GUI style
        style = ttk.Style()
        style.configure('TButton', font=('Arial', 18), width=20)
        style.configure('TBox.TLabel', font=('Arial', 18, 'bold'), background='#1E90FF')
        style.configure('TLabel', font=('Arial', 16), foreground='white', background='#1E90FF')
        style.configure('TImage.TLabel', background='#1E90FF')

        # Create Start button
        start_button = ttk.Button(self.root, text="START", command=self.train_and_predict, style='TButton')
        start_button.place(relx=0.5, rely=0.8, anchor='center')

        # Initialize classifiers
        self.cheating_classifier = None
        self.fighting_classifier = None
        self.second_frame = None

    def train_and_predict(self):
        # Train classifiers and open the second window
        self.train_classifier(training_path="dataset1/invigi_train/", testing_path="dataset1/invi_test/", output_label="Cheating")
        self.train_classifier(training_path="dataset2/invigi_train/", testing_path="dataset2/invi_test/", output_label="Fighting")
        self.root.withdraw()
        self.open_second_frame_for_detection_type()

    def on_close(self):
        # Handle close event
        self.root.destroy()

    def train_classifier(self, training_path, testing_path, output_label):
        # Train a binary image classifier
        classifier = Sequential()
        classifier.add(Convolution2D(32, 3, 3, input_shape=(256, 256, 3), activation='relu'))
        classifier.add(MaxPooling2D(pool_size=(2, 2)))
        classifier.add(Convolution2D(32, 3, 3, activation='relu'))
        classifier.add(MaxPooling2D(pool_size=(2, 2)))
        classifier.add(Convolution2D(32, 3, 3, activation='relu'))
        classifier.add(MaxPooling2D(pool_size=(2, 2)))
        classifier.add(Flatten())
        classifier.add(Dense(units=128, activation='relu'))
        classifier.add(Dense(units=1, activation='sigmoid'))
        classifier.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

        train_datagen = ImageDataGenerator(rescale=1./255, shear_range=0.2, zoom_range=0.2, horizontal_flip=True)
        test_datagen = ImageDataGenerator(rescale=1./255)

        positive_train_path = os.path.join(training_path, f"{output_label.lower()}/")
        negative_train_path = os.path.join(training_path, f"not_{output_label.lower()}/")

        print(f"Positive Train Path ({output_label}):", positive_train_path)
        print(f"Negative Train Path (not {output_label}):", negative_train_path)

        training_set = train_datagen.flow_from_directory(training_path,
                                                         target_size=(256, 256),
                                                         batch_size=8,
                                                         class_mode='binary')

        print("Training Set Length:", len(training_set))

        if len(training_set) == 0:
            print("No training batches generated. Please check your dataset path and structure.")

        test_set = test_datagen.flow_from_directory(testing_path,
                                                    target_size=(256, 256),
                                                    batch_size=8,
                                                    class_mode='binary')

        classifier.fit(training_set,
                       steps_per_epoch=len(training_set),
                       epochs=45,
                       validation_data=test_set,
                       validation_steps=len(test_set))

# Save the trained classifier based on the output label
        if output_label.lower() == "cheating":
            self.cheating_classifier = classifier
        elif output_label.lower() == "fighting":
            self.fighting_classifier = classifier

    def open_second_frame_for_detection_type(self):
        # Open the second window for selecting detection type
        if self.root:
            second_window = tk.Toplevel(self.root)
            SecondWindow(second_window, self.cheating_classifier, self.fighting_classifier)

    def open_second_frame_for_prediction(self):
        # Open the second window for providing a picture to predict
        if self.root:
            self.second_frame = tk.Toplevel(self.root)
            self.second_frame.title("Provide Picture to Predict")
            self.second_frame.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}")
            self.second_frame.configure(bg='#1E90FF')
            self.second_frame.protocol("WM_DELETE_WINDOW", self.on_second_frame_close)

            bg_image_path = "Background_window2_Pic.jpg"
            bg_image = ImageTk.PhotoImage(Image.open(bg_image_path).resize((self.root.winfo_screenwidth(), self.root.winfo_screenheight())))
            bg_label = ttk.Label(self.second_frame, image=bg_image)
            bg_label.image = bg_image
            bg_label.place(relx=0.5, rely=0.5, anchor='center')

            self.select_image_button = ttk.Button(self.second_frame, text="Select Image", command=self.load_image, style='TButton')
            self.select_image_button.pack(pady=10)

            self.image_label = ttk.Label(self.second_frame, style='TImage.TLabel')
            self.image_label.pack(pady=10)
            self.predict_button = ttk.Button(self.second_frame, text="Predict", command=self.predict_image, style='TButton')
            self.predict_button.pack(pady=10)

            self.exit_button = ttk.Button(self.second_frame, text="Exit", command=self.on_exit_button_click, style='TButton')
            self.exit_button.pack(pady=10)

            self.result_label = ttk.Label(self.second_frame, text="", font=('Arial', 16), style='TLabel')
            self.result_label.pack(pady=10)

    def on_second_frame_close(self):
        # Handle the close event for the second window
        if self.root:
            self.root.deiconify()
            self.second_frame.destroy()

    def on_exit_button_click(self):
        # Handle the exit button click event
        if self.root:
            self.root.destroy()
            if self.second_frame:
                self.second_frame.destroy()

    def load_image(self):
        # Load an image for prediction
        self.result_label.config(text="")
        
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            self.image = Image.open(file_path)
            self.image.thumbnail((400, 400))
            self.tk_image = ImageTk.PhotoImage(self.image)
            self.image_label.config(image=self.tk_image)
            self.image_label.image = self.tk_image
            self.selected_image_path = file_path

    def predict_image(self):
        # Predict the class of the selected image
        if hasattr(self, 'selected_image_path'):
            img = load_img(self.selected_image_path, target_size=(256, 256))
            img_array = img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array /= 255.0

            result = None
            if self.cheating_classifier is not None:
                result = self.cheating_classifier.predict(img_array)
                if result[0, 0] > 0.5:
                    self.result_label.config(text="The image is Cheating", foreground="red")

            if self.fighting_classifier is not None:
                result = self.fighting_classifier.predict(img_array)
                if result[0, 0] > 0.5:
                    self.result_label.config(text="The image is Fighting", foreground="red")

            if result is None or result[0, 0] <= 0.5:
                self.result_label.config(text="The image is Not Cheating/Fighting", foreground="green")
        else:
            self.result_label.config(text="Please select an image first or train the classifiers", foreground="red")

if __name__ == "__main__":
    # Create the main application window
    root = tk.Tk()
    app = StudentActivityRecognitionApp(root)
    root.mainloop()